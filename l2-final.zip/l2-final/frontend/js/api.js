// Central place for talking to the backend + shared UI helpers.
const API_BASE = "/api";

function getToken() {
  return localStorage.getItem("lms_token");
}

function getUser() {
  const raw = localStorage.getItem("lms_user");
  return raw ? JSON.parse(raw) : null;
}

function setSession(token, user) {
  localStorage.setItem("lms_token", token);
  localStorage.setItem("lms_user", JSON.stringify(user));
}

function clearSession() {
  localStorage.removeItem("lms_token");
  localStorage.removeItem("lms_user");
}

async function apiRequest(path, { method = "GET", body, auth = false } = {}) {
  const headers = { "Content-Type": "application/json" };
  if (auth) {
    const token = getToken();
    if (token) headers["Authorization"] = `Bearer ${token}`;
  }

  const res = await fetch(API_BASE + path, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });

  let data = {};
  try {
    data = await res.json();
  } catch (_) {
    /* no body */
  }

  if (!res.ok) {
    throw new Error(data.error || "Something went wrong. Please try again.");
  }
  return data;
}

function showNotice(el, message, type = "success") {
  el.textContent = message;
  el.className = `notice show ${type}`;
}

function requireLogin() {
  if (!getToken()) {
    window.location.href = "login.html";
  }
}

function renderHeaderAuthState() {
  const chip = document.getElementById("userChip");
  if (!chip) return;
  const user = getUser();
  if (user) {
    chip.innerHTML = `Signed in as <strong>${user.username}</strong> <button id="logoutBtn">Log out</button>`;
    document.getElementById("logoutBtn").addEventListener("click", () => {
      clearSession();
      window.location.href = "index.html";
    });
  } else {
    chip.innerHTML = `<a href="login.html">Login</a>`;
  }
}

document.addEventListener("DOMContentLoaded", renderHeaderAuthState);
