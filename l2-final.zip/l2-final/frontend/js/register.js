const USERNAME_REGEX = /^[a-zA-Z0-9_]+$/;
const EMAIL_REGEX = /^[a-zA-Z]+\.[a-zA-Z0-9]+@gmail\.com$/;
const PASSWORD_REGEX = /^(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*(),.?":{}|<>_\-]).{8,}$/;

function clearFieldErrors() {
  ["username", "email", "password"].forEach((f) => {
    const el = document.getElementById(`err-${f}`);
    if (el) el.textContent = "";
  });
}

document.getElementById("registerForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  clearFieldErrors();

  const username = document.getElementById("username").value.trim();
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;
  const notice = document.getElementById("notice");

  let valid = true;
  if (!USERNAME_REGEX.test(username)) {
    document.getElementById("err-username").textContent =
      "Username may only contain letters, numbers, or underscores.";
    valid = false;
  }
  if (!EMAIL_REGEX.test(email)) {
    document.getElementById("err-email").textContent =
      "Email must follow the format letters.numbers@gmail.com";
    valid = false;
  }
  if (!PASSWORD_REGEX.test(password)) {
    document.getElementById("err-password").textContent =
      "Min. 8 characters with an uppercase letter, a number, and a special character.";
    valid = false;
  }
  if (!valid) return;

  try {
    const data = await apiRequest("/auth/register", {
      method: "POST",
      body: { username, email, password },
    });
    showNotice(notice, data.message, "success");
    document.getElementById("registerForm").reset();
    setTimeout(() => (window.location.href = "login.html"), 1200);
  } catch (err) {
    showNotice(notice, err.message, "error");
  }
});
