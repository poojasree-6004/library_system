requireLogin();

document.getElementById("searchForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const title = document.getElementById("title").value.trim();
  const notice = document.getElementById("notice");
  const resultsEl = document.getElementById("results");
  resultsEl.innerHTML = "";

  try {
    const data = await apiRequest(`/books/search?title=${encodeURIComponent(title)}`, {
      auth: true,
    });

    if (!data.found) {
      showNotice(notice, data.message, "error");
      return;
    }

    notice.className = "notice";
    resultsEl.innerHTML = data.results
      .map(
        (b) => `
      <div class="book-row">
        <div>
          <div class="book-title">${b.title}</div>
          <div class="book-author">${b.author || ""}</div>
        </div>
        <div style="display:flex; align-items:center; gap: 14px;">
          <span class="book-meta">${b.copies_available}/${b.copies_total} available</span>
          <button class="btn btn-primary" data-title="${b.title.replace(/"/g, "&quot;")}" ${
          b.copies_available < 1 ? "disabled" : ""
        }>Reserve</button>
        </div>
      </div>`
      )
      .join("");

    resultsEl.querySelectorAll("button[data-title]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        try {
          const res = await apiRequest("/books/borrow", {
            method: "POST",
            auth: true,
            body: { title: btn.dataset.title },
          });
          showNotice(notice, res.message, "success");
        } catch (err) {
          showNotice(notice, err.message, "error");
        }
      });
    });
  } catch (err) {
    showNotice(notice, err.message, "error");
  }
});
