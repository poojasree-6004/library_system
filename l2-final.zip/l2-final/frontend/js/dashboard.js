requireLogin();

async function loadDashboard() {
  try {
    const { user, activeLoans } = await apiRequest("/dashboard/me", { auth: true });
    document.getElementById("welcomeHeader").textContent = `Welcome back, ${user.username}!`;

    const loansEl = document.getElementById("loansList");
    if (activeLoans.length === 0) {
      loansEl.innerHTML = `<p class="section-sub">You have no active loans.</p>`;
    } else {
      loansEl.innerHTML = activeLoans
        .map(
          (l) => `
        <div class="book-row">
          <div>
            <div class="book-title">${l.title}</div>
            <div class="book-meta">Borrowed ${l.borrowed_at.slice(0, 10)}</div>
          </div>
          <div class="book-meta">Due ${l.due_date}</div>
        </div>`
        )
        .join("");
    }
  } catch (err) {
    if (err.message.includes("log in")) {
      clearSession();
      window.location.href = "login.html";
    }
  }

  try {
    const { results } = await apiRequest("/books/new-arrivals");
    const arrivalsEl = document.getElementById("arrivalsList");
    arrivalsEl.innerHTML = results
      .map(
        (b) => `
      <div class="book-row">
        <div>
          <div class="book-title">${b.title}</div>
          <div class="book-author">${b.author || ""}</div>
        </div>
        <div class="book-meta">${b.copies_available} available</div>
      </div>`
      )
      .join("");
  } catch (err) {
    document.getElementById("arrivalsList").innerHTML = `<p class="section-sub">Could not load new arrivals.</p>`;
  }
}

loadDashboard();
