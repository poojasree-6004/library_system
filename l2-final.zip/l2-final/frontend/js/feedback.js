document.getElementById("feedbackForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const message = document.getElementById("message").value.trim();
  const notice = document.getElementById("notice");

  try {
    const data = await apiRequest("/feedback", {
      method: "POST",
      auth: true,
      body: { message },
    });
    showNotice(notice, data.message, "success");
    document.getElementById("feedbackForm").reset();
  } catch (err) {
    showNotice(notice, err.message, "error");
  }
});
