requireLogin();

document.getElementById("fineForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const dueDate = document.getElementById("dueDate").value;
  const returnDate = document.getElementById("returnDate").value;
  const notice = document.getElementById("notice");

  try {
    const data = await apiRequest("/fines/calculate", {
      method: "POST",
      auth: true,
      body: { dueDate, returnDate },
    });
    showNotice(notice, data.message, data.onTime ? "success" : "error");
  } catch (err) {
    showNotice(notice, err.message, "error");
  }
});
