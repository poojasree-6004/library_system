document.getElementById("loginForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const username = document.getElementById("username").value.trim();
  const password = document.getElementById("password").value;
  const notice = document.getElementById("notice");

  try {
    const data = await apiRequest("/auth/login", {
      method: "POST",
      body: { username, password },
    });
    setSession(data.token, data.user);
    showNotice(notice, data.message, "success");
    setTimeout(() => (window.location.href = "dashboard.html"), 700);
  } catch (err) {
    showNotice(notice, err.message, "error");
  }
});
