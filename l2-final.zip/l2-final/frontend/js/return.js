requireLogin();

document.getElementById("returnForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const title = document.getElementById("title").value.trim();
  const returnDate = document.getElementById("returnDate").value;
  const notice = document.getElementById("notice");

  try {
    const data = await apiRequest("/books/return", {
      method: "POST",
      auth: true,
      body: { title, returnDate },
    });
    showNotice(notice, data.message, "success");
    document.getElementById("returnForm").reset();
  } catch (err) {
    showNotice(notice, err.message, "error");
  }
});
