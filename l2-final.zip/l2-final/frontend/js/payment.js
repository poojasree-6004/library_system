requireLogin();

document.getElementById("paymentForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const amount = document.getElementById("amount").value;
  const method = document.getElementById("method").value;
  const notice = document.getElementById("notice");

  try {
    const data = await apiRequest("/payments", {
      method: "POST",
      auth: true,
      body: { amount, method },
    });
    showNotice(notice, `${data.message} (Ref: ${data.reference})`, "success");
    document.getElementById("paymentForm").reset();
  } catch (err) {
    showNotice(notice, err.message, "error");
  }
});
