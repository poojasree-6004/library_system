# 📚 Library Management System

A full-stack web application for managing a library's day-to-day operations — member
registration, authentication, catalog search, borrowing/returns, fine calculation, and
payments.

Built as a portfolio project to demonstrate REST API design, authentication, and a clean
vanilla-JS frontend without relying on a heavy framework.

## Features

- **User registration & login** with server-side validation (username, Gmail-style email,
  strong password) and hashed passwords (bcrypt)
- **JWT-based authentication** protecting all library actions
- **Catalog search** across a seeded set of classic CS textbooks
- **Borrow / return workflow** with live copy-availability tracking
- **Fine calculator** (₹5/day late fee) with instant feedback
- **Payments** with method selection (UPI, Card, NetBanking, Cash) and a generated
  reference number
- **Feedback form**
- **Dashboard** showing new arrivals and the logged-in user's active loans
- Fully responsive UI styled to resemble a real library portal

## Tech Stack

| Layer     | Technology                                              |
|-----------|----------------------------------------------------------|
| Frontend  | HTML5, CSS3, vanilla JavaScript (Fetch API)               |
| Backend   | Node.js, Express                                          |
| Auth      | JSON Web Tokens (jsonwebtoken), bcryptjs password hashing |
| Data      | Lightweight JSON file store (zero native dependencies — see note below) |

> **Why a JSON file store instead of a SQL database?**
> The project is structured so the persistence layer is fully isolated in
> `backend/db/store.js`. This keeps the demo dependency-free and easy to run anywhere
> (no native compilation, no separate database server to install). Swapping in
> PostgreSQL, MySQL, or SQLite is a matter of reimplementing the functions exported
> from `store.js` — the routes never touch storage directly. This is a good talking
> point in an interview: it shows you understand separation of concerns / the
> repository pattern.

## Project Structure

```
library-management-system/
├── backend/
│   ├── db/
│   │   └── store.js          # data access layer (swap-able persistence)
│   ├── middleware/
│   │   └── auth.js           # JWT verification middleware
│   ├── routes/
│   │   ├── auth.js           # register / login
│   │   ├── books.js          # search / borrow / return
│   │   ├── fines.js          # fine calculation
│   │   ├── payments.js       # payment processing
│   │   ├── feedback.js       # feedback submission
│   │   └── dashboard.js      # user profile + active loans
│   ├── server.js             # Express app entry point
│   ├── package.json
│   └── .env.example
└── frontend/
    ├── index.html, about.html, register.html, login.html,
    │   dashboard.html, search.html, return.html, fine.html,
    │   payment.html, feedback.html
    ├── css/style.css
    └── js/                    # one script per page + shared api.js helper
```

## Getting Started

### Prerequisites
- [Node.js](https://nodejs.org/) v18 or later

### Installation & Run

```bash
cd backend
cp .env.example .env      # optionally edit PORT / JWT_SECRET
npm install
npm start
```

The server starts at **http://localhost:4000** and also serves the frontend directly,
so you can open that URL in your browser and use the whole app immediately — no
separate frontend server or build step required.

On first run, the catalog is automatically seeded with 10 sample books and a
`backend/db/library.json` file is created to store all data (users, loans, payments,
feedback). Delete that file at any time to reset the app to a clean state.

### Try it out
1. Open `http://localhost:4000`
2. Click **Register** and create an account
   - Username: letters, numbers, underscores only
   - Email: must look like `firstname.lastname@gmail.com`
   - Password: 8+ characters, with an uppercase letter, a number, and a special character
3. **Login**, then explore the dashboard: search the catalog, borrow a book, return it,
   calculate a late fine, and make a payment.

## API Overview

| Method | Endpoint                     | Auth | Description                          |
|--------|-------------------------------|------|---------------------------------------|
| POST   | `/api/auth/register`          | No   | Create a new account                  |
| POST   | `/api/auth/login`             | No   | Log in, returns a JWT                 |
| GET    | `/api/books/search?title=`    | Yes  | Search the catalog                    |
| GET    | `/api/books/new-arrivals`     | No   | Latest additions to the catalog       |
| POST   | `/api/books/borrow`           | Yes  | Reserve/borrow a book                 |
| POST   | `/api/books/return`           | Yes  | Return a borrowed book                |
| POST   | `/api/fines/calculate`        | Yes  | Calculate a late fine                 |
| POST   | `/api/payments`               | Yes  | Process a payment                     |
| GET    | `/api/payments/history`       | Yes  | Get a user's payment history          |
| POST   | `/api/feedback`               | No   | Submit feedback                       |
| GET    | `/api/dashboard/me`           | Yes  | Get profile + active loans            |

All authenticated endpoints expect `Authorization: Bearer <token>`.

## Ideas for Extending This Project

- Swap the JSON store for PostgreSQL/MySQL via an ORM (Prisma/Sequelize)
- Add an admin role for managing the catalog (add/remove/edit books)
- Add email notifications for due-date reminders
- Add pagination and sorting to the catalog search
- Write automated tests (Jest + Supertest) for the API routes
- Containerize with Docker for one-command deployment

## License

This project is free to use as a personal portfolio piece.
