const express = require("express");
const jwt = require("jsonwebtoken");
const store = require("../db/store");

const router = express.Router();

// POST /api/feedback  { message }  -- optionally authenticated
router.post("/", (req, res) => {
  const { message } = req.body || {};
  if (!message || !message.trim()) {
    return res.status(400).json({ error: "Please enter your feedback before submitting." });
  }

  let userId = null;
  const header = req.headers["authorization"] || "";
  if (header.startsWith("Bearer ")) {
    try {
      const payload = jwt.verify(
        header.slice(7),
        process.env.JWT_SECRET || "dev_secret_change_me"
      );
      userId = payload.id;
    } catch (_) {
      // ignore invalid token, treat as anonymous feedback
    }
  }

  store.createFeedback({ userId, message: message.trim() });

  res.status(201).json({ message: "Thank you for your feedback!" });
});

module.exports = router;
