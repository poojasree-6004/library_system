const express = require("express");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();
const FINE_PER_DAY = Number(process.env.FINE_PER_DAY || 5);

// POST /api/fines/calculate  { dueDate, returnDate }
router.post("/calculate", requireAuth, (req, res) => {
  const { dueDate, returnDate } = req.body || {};
  if (!dueDate || !returnDate) {
    return res.status(400).json({ error: "Both the due date and return date are required." });
  }

  const due = new Date(dueDate);
  const returned = new Date(returnDate);

  if (isNaN(due.getTime()) || isNaN(returned.getTime())) {
    return res.status(400).json({ error: "Please provide valid dates." });
  }

  const diffDays = Math.round((returned - due) / (1000 * 60 * 60 * 24));

  if (diffDays <= 0) {
    return res.json({ onTime: true, daysLate: 0, fine: 0, message: "No Fine — returned on time." });
  }

  const fine = diffDays * FINE_PER_DAY;
  return res.json({
    onTime: false,
    daysLate: diffDays,
    finePerDay: FINE_PER_DAY,
    fine,
    message: `Book returned ${diffDays} day(s) late. Fine: ₹${fine}`,
  });
});

module.exports = router;
