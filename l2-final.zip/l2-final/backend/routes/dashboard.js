const express = require("express");
const store = require("../db/store");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();

// GET /api/dashboard/me
router.get("/me", requireAuth, (req, res) => {
  const userRecord = store.findUserById(req.user.id);
  if (!userRecord) {
    return res.status(404).json({ error: "User not found." });
  }
  const user = {
    id: userRecord.id,
    username: userRecord.username,
    email: userRecord.email,
    created_at: userRecord.created_at,
  };
  const activeLoans = store.getActiveLoansForUser(req.user.id);

  res.json({ user, activeLoans });
});

module.exports = router;
