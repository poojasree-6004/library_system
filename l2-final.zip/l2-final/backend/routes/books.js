const express = require("express");
const store = require("../db/store");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();

// GET /api/books/search?title=...
router.get("/search", (req, res) => {
  const title = (req.query.title || "").trim();
  if (!title) {
    return res.status(400).json({ error: "Please enter a book title to search for." });
  }

  const results = store.searchBooksByTitle(title);

  if (results.length === 0) {
    return res.json({ found: false, message: `No results for "${title}" in the catalog.`, results: [] });
  }

  return res.json({ found: true, results });
});

// GET /api/books/new-arrivals
router.get("/new-arrivals", (req, res) => {
  res.json({ results: store.getNewArrivals(6) });
});

// POST /api/books/borrow  { title }
router.post("/borrow", requireAuth, (req, res) => {
  const { title } = req.body || {};
  if (!title) return res.status(400).json({ error: "Book title is required." });

  const book = store.findBookByExactTitle(title.trim());

  if (!book) return res.status(404).json({ error: `"${title}" was not found in the catalog.` });
  if (book.copies_available < 1)
    return res.status(400).json({ error: `No copies of "${book.title}" are currently available.` });

  const dueDate = new Date();
  dueDate.setDate(dueDate.getDate() + 14);
  const dueDateStr = dueDate.toISOString().slice(0, 10);

  store.adjustBookAvailability(book.id, -1);
  store.createLoan({ userId: req.user.id, bookId: book.id, dueDate: dueDateStr });

  res.status(201).json({
    message: `"${book.title}" reserved successfully. Due back on ${dueDateStr}.`,
  });
});

// POST /api/books/return  { title, returnDate }
router.post("/return", requireAuth, (req, res) => {
  const { title, returnDate } = req.body || {};
  if (!title || !returnDate) {
    return res.status(400).json({ error: "Book title and return date are required." });
  }

  const match = store.findActiveLoanByUserAndTitle(req.user.id, title.trim());

  if (!match) {
    return res.status(404).json({
      error: `No active loan found for "${title}" under your account.`,
    });
  }

  store.markLoanReturned(match.loan.id, returnDate);
  store.adjustBookAvailability(match.book.id, 1);

  res.json({
    message: `"${match.book.title}" was returned successfully on ${returnDate}.`,
    title: match.book.title,
    returnDate,
  });
});

module.exports = router;
