const express = require("express");
const store = require("../db/store");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();
const VALID_METHODS = ["UPI", "Credit/Debit Card", "NetBanking", "Cash"];

// POST /api/payments  { amount, method }
router.post("/", requireAuth, (req, res) => {
  const { amount, method } = req.body || {};
  const numericAmount = Number(amount);

  if (!numericAmount || numericAmount <= 0) {
    return res.status(400).json({ error: "Please enter a valid payment amount." });
  }
  if (!VALID_METHODS.includes(method)) {
    return res.status(400).json({ error: "Please select a valid payment method." });
  }

  const reference = "PAY" + Date.now().toString().slice(-8);

  store.createPayment({ userId: req.user.id, amount: numericAmount, method, reference });

  res.status(201).json({
    message: `Payment of ₹${numericAmount} via ${method} was successful.`,
    reference,
  });
});

// GET /api/payments/history
router.get("/history", requireAuth, (req, res) => {
  res.json({ results: store.getPaymentsForUser(req.user.id) });
});

module.exports = router;
