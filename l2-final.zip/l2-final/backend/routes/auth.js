const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const store = require("../db/store");

const router = express.Router();

const USERNAME_REGEX = /^[a-zA-Z0-9_]+$/;
const EMAIL_REGEX = /^[a-zA-Z]+\.[a-zA-Z0-9]+@gmail\.com$/;
const PASSWORD_REGEX = /^(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*(),.?":{}|<>_\-]).{8,}$/;

router.post("/register", (req, res) => {
  const { username, email, password } = req.body || {};

  if (!username || !email || !password) {
    return res.status(400).json({ error: "Username, email, and password are all required." });
  }
  if (!USERNAME_REGEX.test(username)) {
    return res.status(400).json({
      error: "Username may only contain letters, numbers, or underscores.",
    });
  }
  if (!EMAIL_REGEX.test(email)) {
    return res.status(400).json({
      error: "Email must follow the format letters.numbers@gmail.com",
    });
  }
  if (!PASSWORD_REGEX.test(password)) {
    return res.status(400).json({
      error:
        "Password must be at least 8 characters and include an uppercase letter, a number, and a special character.",
    });
  }

  try {
    const existing = store.findUserByUsernameOrEmail(username, email);
    if (existing) {
      return res.status(409).json({ error: "That username or email is already registered." });
    }

    const passwordHash = bcrypt.hashSync(password, 10);
    const user = store.createUser({ username, email, passwordHash });

    return res.status(201).json({
      message: `Registration successful! Welcome, ${username}.`,
      userId: user.id,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Something went wrong during registration." });
  }
});

router.post("/login", (req, res) => {
  const { username, password } = req.body || {};

  if (!username || !password) {
    return res.status(400).json({ error: "Username and password are required." });
  }

  const user = store.findUserByUsername(username);
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(401).json({ error: "Invalid username or password." });
  }

  const token = jwt.sign(
    { id: user.id, username: user.username },
    process.env.JWT_SECRET || "dev_secret_change_me",
    { expiresIn: "2h" }
  );

  return res.json({
    message: `Welcome back, ${user.username}!`,
    token,
    user: { id: user.id, username: user.username, email: user.email },
  });
});

module.exports = router;
