// A tiny dependency-free JSON file "database".
// Good enough for a demo / portfolio project — swap for Postgres/MySQL in production.
const fs = require("fs");
const path = require("path");

const DB_FILE = path.join(__dirname, "library.json");

const SEED_BOOKS = [
  ["Data Structures and Algorithms", "Narasimha Karumanchi"],
  ["Introduction to Algorithms", "Cormen, Leiserson, Rivest, Stein"],
  ["Artificial Intelligence: A Modern Approach", "Russell & Norvig"],
  ["The C Programming Language", "Kernighan & Ritchie"],
  ["Operating System Concepts", "Silberschatz, Galvin, Gagne"],
  ["Computer Networking: A Top-Down Approach", "Kurose & Ross"],
  ["Design Patterns: Elements of Reusable Object-Oriented Software", "Gamma, Helm, Johnson, Vlissides"],
  ["Database System Concepts", "Silberschatz, Korth, Sudarshan"],
  ["Clean Code: A Handbook of Agile Software Craftsmanship", "Robert C. Martin"],
  ["The Pragmatic Programmer", "Hunt & Thomas"],
];

function defaultData() {
  return {
    nextIds: { users: 1, books: 1, loans: 1, payments: 1, feedback: 1 },
    users: [],
    books: SEED_BOOKS.map(([title, author], i) => ({
      id: i + 1,
      title,
      author,
      copies_total: 5,
      copies_available: 5,
      added_at: new Date().toISOString(),
    })),
    loans: [],
    payments: [],
    feedback: [],
  };
}

let data;

function load() {
  if (fs.existsSync(DB_FILE)) {
    try {
      data = JSON.parse(fs.readFileSync(DB_FILE, "utf-8"));
      // Bump nextIds.books ahead of seed data in case of partial file.
      const maxBookId = Math.max(0, ...data.books.map((b) => b.id));
      data.nextIds.books = Math.max(data.nextIds.books, maxBookId + 1);
      return;
    } catch (err) {
      console.error("Could not parse library.json, recreating it.", err);
    }
  }
  data = defaultData();
  save();
  console.log(`Seeded ${SEED_BOOKS.length} books into the catalog.`);
}

function save() {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}

function nextId(entity) {
  const id = data.nextIds[entity]++;
  save();
  return id;
}

load();

// ---------------- Users ----------------
function findUserByUsernameOrEmail(username, email) {
  return data.users.find((u) => u.username === username || u.email === email) || null;
}
function findUserByUsername(username) {
  return data.users.find((u) => u.username === username) || null;
}
function findUserById(id) {
  return data.users.find((u) => u.id === id) || null;
}
function createUser({ username, email, passwordHash }) {
  const user = {
    id: nextId("users"),
    username,
    email,
    password_hash: passwordHash,
    created_at: new Date().toISOString(),
  };
  data.users.push(user);
  save();
  return user;
}

// ---------------- Books ----------------
function searchBooksByTitle(titleFragment) {
  const q = titleFragment.toLowerCase();
  return data.books.filter((b) => b.title.toLowerCase().includes(q));
}
function findBookByExactTitle(title) {
  const q = title.toLowerCase();
  return data.books.find((b) => b.title.toLowerCase() === q) || null;
}
function findBookById(id) {
  return data.books.find((b) => b.id === id) || null;
}
function getNewArrivals(limit = 6) {
  return [...data.books]
    .sort((a, b) => new Date(b.added_at) - new Date(a.added_at))
    .slice(0, limit);
}
function adjustBookAvailability(bookId, delta) {
  const book = findBookById(bookId);
  if (book) {
    book.copies_available += delta;
    save();
  }
  return book;
}

// ---------------- Loans ----------------
function createLoan({ userId, bookId, dueDate }) {
  const loan = {
    id: nextId("loans"),
    user_id: userId,
    book_id: bookId,
    borrowed_at: new Date().toISOString(),
    due_date: dueDate,
    returned_at: null,
    status: "borrowed",
  };
  data.loans.push(loan);
  save();
  return loan;
}
function findActiveLoanByUserAndTitle(userId, title) {
  const q = title.toLowerCase();
  const candidates = data.loans
    .filter((l) => l.user_id === userId && l.status === "borrowed")
    .map((l) => ({ loan: l, book: findBookById(l.book_id) }))
    .filter(({ book }) => book && book.title.toLowerCase() === q)
    .sort((a, b) => new Date(b.loan.borrowed_at) - new Date(a.loan.borrowed_at));
  return candidates[0] || null;
}
function markLoanReturned(loanId, returnDate) {
  const loan = data.loans.find((l) => l.id === loanId);
  if (loan) {
    loan.status = "returned";
    loan.returned_at = returnDate;
    save();
  }
  return loan;
}
function getActiveLoansForUser(userId) {
  return data.loans
    .filter((l) => l.user_id === userId && l.status === "borrowed")
    .map((l) => ({ ...l, title: findBookById(l.book_id)?.title || "Unknown title" }))
    .sort((a, b) => new Date(b.borrowed_at) - new Date(a.borrowed_at));
}

// ---------------- Payments ----------------
function createPayment({ userId, amount, method, reference }) {
  const payment = {
    id: nextId("payments"),
    user_id: userId,
    amount,
    method,
    reference,
    created_at: new Date().toISOString(),
  };
  data.payments.push(payment);
  save();
  return payment;
}
function getPaymentsForUser(userId) {
  return data.payments
    .filter((p) => p.user_id === userId)
    .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
}

// ---------------- Feedback ----------------
function createFeedback({ userId, message }) {
  const entry = {
    id: nextId("feedback"),
    user_id: userId,
    message,
    created_at: new Date().toISOString(),
  };
  data.feedback.push(entry);
  save();
  return entry;
}

module.exports = {
  findUserByUsernameOrEmail,
  findUserByUsername,
  findUserById,
  createUser,
  searchBooksByTitle,
  findBookByExactTitle,
  findBookById,
  getNewArrivals,
  adjustBookAvailability,
  createLoan,
  findActiveLoanByUserAndTitle,
  markLoanReturned,
  getActiveLoansForUser,
  createPayment,
  getPaymentsForUser,
  createFeedback,
};
